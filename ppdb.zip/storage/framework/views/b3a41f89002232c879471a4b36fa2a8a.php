<div style="display: <?php echo e(isset($elementId) ? 'none' : 'block'); ?>">
    <main id="print-smart-content-<?php echo e($elementId ?? ''); ?>" style="color: black;" wire:ignore>
        <?php echo $content; ?>

        <iframe style="display: none" id="print-smart-iframe-<?php echo e($elementId ?? ''); ?>"></iframe>
    </main>


</div>
<?php /**PATH C:\Users\zedla\Desktop\ppdb\vendor\torgodly\html2media\src\/../resources/views/tables/actions/html-2-media-table-action.blade.php ENDPATH**/ ?>