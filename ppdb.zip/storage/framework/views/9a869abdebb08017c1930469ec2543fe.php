<?php 
use App\Models\Ketua;
use App\Models\Sekolah;
use App\Models\Pimpinan;
use App\Models\Sekretaris;
use App\Models\TahunPendaftaran;
use Illuminate\Support\Facades\Storage;

    $instansi = Sekolah::first();
    $tahunPendaftaran = TahunPendaftaran::where('status', 'Aktif')->first();
    $sekretaris = Sekretaris::where('status', 'Aktif')->first();
    $ketua = Ketua::where('status', 'Aktif')->first();
    $pimpinan = Pimpinan::where('status', 'Aktif')->first();
    $jenisKelamin = $record->jenis_kelamin === 'Pria' ? 'Laki-laki' : 'Perempuan';

?>

    <table width="100%">
        <tr>
            <td align="center">
                <img src="<?php echo e($instansi->logo_institusi ? Storage::url($instansi->logo_institusi) : asset('img/logo-institusi.png')); ?>" alt="Logo Instansi" width="90px">
            </td>

            <td align="center">
                <b> KEMENTERIAN AGAMA REPUBLIK INDONESIA </b> <br>
                <b> KANTOR KEMENTERIAN AGAMA KABUPATEN PANDEGLANG </b> <br>
                <b> MADRASAH TSANAWIYAH NEGERI 1 PANDEGLANG </b> <br>
                <small>
                    <?php echo e(ucwords(strtolower($instansi->alamat)) ?? ''); ?> <?php echo e(ucwords(strtolower($instansi->kelurahan->nama)) ?? ''); ?>, <?php echo e(ucwords(strtolower($instansi->kecamatan->nama)) ?? ''); ?>, <?php echo e(ucwords(strtolower($instansi->kabupaten->nama)) ?? ''); ?> - <?php echo e(ucwords(strtolower($instansi->provinsi->nama)) ?? ''); ?>

                </small>
                <br>
                <small> Website: <?php echo e($instansi->website ?? 'https://mtsn1pandeglang.sch.id'); ?> Email: <?php echo e($instansi->email ?? 'adm@mtsn1pandeglang.sch.id'); ?>

                </small> <br>
            </td>

            <td align="center">
                <img src="<?php echo e($instansi->logo ? Storage::url($instansi->logo) : asset('img/logo.png')); ?>" alt="Logo Instansi" width="90px">
            </td>
        </tr>
    </table>
    <hr style="border: 1px solid">
    <table width="100%">
        <tr>
            <td>
                <br>
            </td>
        </tr>
        <tr>
            <td align="center" colspan="4">
                <b>FORMULIR PENDAFTARAN</b>
            </td>
        </tr>

        <tr>
            <td align="center" colspan="4">
                <b>TAHUN PELAJARAN <?php echo e($tahunPendaftaran->nama ?? ''); ?></b>
            </td>
        </tr>

        <tr>
            <td>
                <br>
            </td>
        </tr>

        <tr>
            <td colspan="4">
                <b>DATA PESERTA</b>
            </td>
        </tr>

        <tr>
            <td width="170px">
                <span>Nama Lengkap</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <strong>
                    <?php echo e(ucwords(strtoupper($record->nama)) ?? ''); ?>

                </strong>
            </td>
            <td rowspan="9" width="140px" style="align-content: flex-start">
                <img src="<?php echo e(Storage::url($record->berkas_foto ?? '')); ?>" alt="Foto">
            </td>
        </tr>

        <tr>
            <td>
                <span>Jalur Pendaftaran</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e(ucwords(strtolower($record->jalurPendaftaran->nama)) ?? ''); ?>

            </td>
        </tr>

        <tr>
            <td>
                <span>NISN</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e($record->nisn ?? ''); ?>

            </td>
        </tr>

        <tr>
            <td>
                <span>Tempat, Tanggal Lahir</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e(ucwords(strtolower($record->tempat_lahir)) ?? ''); ?>, <?php echo e(ucwords(strtolower(date('d F Y', strtotime($record->tanggal_lahir)))) ?? ''); ?>

            </td>
        </tr>

        <tr>
            <td>
                <span>Asal Sekolah</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e(ucwords(strtoupper($record->sekolahAsal->nama)) ?? ''); ?>

            </td>
        </tr>

        <tr>
            <td>
                <span>Tahun Lulus</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e($record->tahun_lulus ?? ''); ?>

            </td>
        </tr>

        <tr>
            <td>
                <span>Jenis Lelamin</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e($jenisKelamin ?? ''); ?>

            </td>
        </tr>

        <tr>
            <td>
                <span>Golongan Darah</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e($record->golongan_darah ?? ''); ?>

            </td>
        </tr>
        <tr>
            <td>
                <span>Agama</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td>
                <?php echo e(ucwords(strtolower($record->agama)) ?? ''); ?>

            </td>
        </tr>
        <tr>
            <td>
                <span>Alamat Lengkap</span>
            </td>
            <td>
                <span>:</span>
            </td>
            <td colspan="2">
                <?php echo e(ucwords(strtolower($record->siswa_alamat)) ?? ''); ?>, <?php echo e(ucwords(strtolower($record->siswaKelurahan->nama)) ?? ''); ?>,
                <?php echo e(ucwords(strtolower($record->siswaKecamatan->nama)) ?? ''); ?>, <?php echo e(ucwords(strtolower($record->siswaKabupaten->nama)) ?? ''); ?> - <?php echo e(ucwords(strtolower($record->siswaProvinsi->nama)) ?? ''); ?>

            </td>
        </tr>
    </table>
    <br>

    <table width="100%">
        <tr>
            <td width="70%">
            </td>
            <td>
                <span>
                    <?php echo e(ucwords(strtolower($instansi->kabupaten->nama)) ?? ''); ?>, <?php echo e(date('d F Y', strtotime($record->created_at)) ?? ''); ?>

                </span>
            </td>
        </tr>
        <tr>
            <td>
                <span>
                    Ketua,
                </span>
            </td>
            <td>
                <span>
                    Sekretaris,
                </span>
            </td>
        </tr>
        <tr height="90px">
            <td>
                <span>
                    <img src="<?php echo e($ketua->berkas_tte ? Storage::url($ketua->berkas_tte) : asset('img/tte.png')); ?>" alt="TTE Ketua" width="90px">
                </span>
            </td>
            <td>
                <span>
                    <img src="<?php echo e($sekretaris->berkas_tte ? Storage::url($sekretaris->berkas_tte) : asset('img/tte.png')); ?>" alt="TTE Sekretaris" width="90px">
                </span>
            </td>
        </tr>
        <tr>
            <td>
                <span>
                    <strong>
                        <?php echo e($ketua->nama ?? ''); ?>

                    </strong>   
                </span>
            </td>
            <td>
                <span>
                    <strong>
                        <?php echo e($sekretaris->nama ?? ''); ?>

                    </strong>   
                </span>
            </td>
        </tr>
        <tr>
            <td>
                <span>
                    NIP <?php echo e($ketua->nip ?? ''); ?>

                </span>
            </td>
            <td>
                <span>
                    NIP <?php echo e($sekretaris->nip ?? ''); ?>

                </span>
            </td>
        </tr>
    </table>

    <table border="1" width="100%">
        <tr align="center">
            <td>
                Mengetahui,
            </td>
        </tr>
        <tr align="center">
            <td>
                <span>
                    Kepala <?php echo e(ucwords(strtolower($instansi->nama)) ?? 'Madrasah Tsanawiyah Negeri 1 Pandeglang'); ?>,
                </span>
            </td>
        </tr>
        <tr align="center" height="90px">
            <td>
                <span>
                    <img src="<?php echo e($pimpinan->berkas_tte ? Storage::url($pimpinan->berkas_tte) : asset('img/tte.png')); ?>" alt="TTE Pimpinan" width="90px">
                </span>
            </td>
        </tr>
        <tr align="center">
            <td>
                <span>
                    <strong>
                        <?php echo e($pimpinan->nama ?? ''); ?>

                    </strong>  
                </span>
            </td>
        </tr>
        <tr align="center">
            <td>
                <span>
                    NIP <?php echo e($pimpinan->nip ?? ''); ?>

                </span>
            </td>
        </tr>
    </table><?php /**PATH C:\Users\zedla\Desktop\ppdb\resources\views\formulir.blade.php ENDPATH**/ ?>